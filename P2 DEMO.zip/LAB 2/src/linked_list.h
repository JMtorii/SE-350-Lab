/**
 * @file:   linked_list.h
 * @brief:  Linked list implementation header file
 * @author: The coolest guys ever
 * @date:   2014/01/22
 */
 
#include "k_rtx.h"
 
#ifndef LINKED_LIST_H_
#define LINKED_LIST_H_

struct Node;

typedef struct MemBlock {
		U32 *next_blk;
} MemBlock;

/*
typedef struct Node{
		struct Node* next;
		struct Node* prev;
	  MemBlock value;
} Node;

typedef struct Heap{
		U32 size;
	  Node* first;
		MemBlock ;
} Heap;

Heap* h_init();
void h_delete(Heap *list);
void h_push(Heap *list, MemBlock value);
MemBlock* h_pop(Heap *list);*/

// TODO: Stuff here.

#endif
